export class Contact{
    name: String;
    email: String;
    subject: String;
    message: String;
}