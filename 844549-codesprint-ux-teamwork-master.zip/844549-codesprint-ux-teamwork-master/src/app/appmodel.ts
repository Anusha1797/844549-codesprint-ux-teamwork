export class Appointment {
    //id:number;
    firstname:string;
    lastname:string;
    age:number;
    email:string;
    phone:number;
    streetaddress:string;
    city:string;
    state:string;
    country:string; //dropdown
    pincode:number;
    preference:string; //radio
    physchotherapist:string; //radio
    package:number; //radio
    rupees:number;
    slot1:string;
    slot2:string;
    slot3:string;
    slot4:string;
    slot5:string;
     
}